﻿namespace VGP133_A6_Karlsson_VIncent
{
    internal class Player(string name, int age)
    {
        public string Name { get; set; } = name;
        public int Age { get; set; } = age;
    }
}
