﻿using VGP133_A6_Karlsson_VIncent;

Questions questions = new Questions();

//questions.Question1();
//questions.Question2();
//questions.Question3();
//questions.Question4();
//questions.Question5();
