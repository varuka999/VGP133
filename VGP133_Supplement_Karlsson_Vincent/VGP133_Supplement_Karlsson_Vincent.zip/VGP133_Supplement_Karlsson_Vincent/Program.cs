﻿using VGP133_Supplement_Karlsson_Vincent;

Questions questions = new Questions();

//questions.Question1();
//questions.Question2();
//questions.Question3();
//questions.Question4();
