﻿using VGP133_A5_Karlsson_Vincent;

Questions questions = new Questions();

//questions.Question1();
//questions.Question2();
//questions.Question3();
//questions.Question4();