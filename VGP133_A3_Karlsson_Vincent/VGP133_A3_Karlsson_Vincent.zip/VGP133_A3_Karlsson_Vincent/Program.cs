﻿using VGP133_A3_Karlsson_Vincent;

AssignmentQuestions assignmentQuestions = new AssignmentQuestions();

//assignmentQuestions.Question1();
//assignmentQuestions.Question2();

ShoppingApp shoppingApp = new ShoppingApp();

shoppingApp.RunApp();