﻿using VGP133_A2_Karlsson_Vincent;

AssignmentQuestions assignmentQuestions = new AssignmentQuestions();

//assignmentQuestions.Question1();

//assignmentQuestions.Question2();

//assignmentQuestions.Question3();

//assignmentQuestions.Question4();

//assignmentQuestions.Question5();
