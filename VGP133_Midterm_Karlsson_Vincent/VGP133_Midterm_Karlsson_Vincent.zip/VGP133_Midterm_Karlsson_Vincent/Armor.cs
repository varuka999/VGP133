﻿namespace VGP133_Midterm_Karlsson_Vincent
{
    public class Armor(int hpBonus, int attBonus, int defBonus) : Equipment(hpBonus, attBonus, defBonus)
    {
        public void Test()
        {
            //HPBonus;
        }
    }
}
